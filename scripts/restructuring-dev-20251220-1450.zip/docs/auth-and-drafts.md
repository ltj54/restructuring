# Authentication and guest drafts

- Guest data is stored in `localStorage` under the keys in `frontend/src/utils/draftSync.ts` (`myPlan`, `myPlanDiaries`, `insuranceSnapshotDraft`, etc.). Guests get a `...PendingSync` flag when they enter data so we know to push it later.
- On login, `useAuth` triggers `syncAnonymousDrafts()` which copies pending guest data to the authenticated user via the existing APIs (`/plan/me` and insurance snapshot). Flags are cleared after a successful sync.
- Plan drafts are persisted from the wizard and plan pages whenever the user has entered data (phase/needs/persona or diary text). See `frontend/src/pages/WizardPage.tsx` and `frontend/src/pages/PlanPage.tsx`.
- Insurance drafts already persist on change and mark pending via `markInsurancePendingSync()`; sync happens on the first login.
- Session lifetime: JWT expiry is set to 24 hours (`backend/src/main/resources/application.yml` -> `jwt.expiration-hours: 24`). The login response also returns `expiresInSeconds` for clients if they need it.
