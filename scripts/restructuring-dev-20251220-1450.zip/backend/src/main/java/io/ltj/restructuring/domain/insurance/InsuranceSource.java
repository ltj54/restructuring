package io.ltj.restructuring.domain.insurance;

public enum InsuranceSource {
    EMPLOYER,
    PRIVATE,
    UNKNOWN
}
