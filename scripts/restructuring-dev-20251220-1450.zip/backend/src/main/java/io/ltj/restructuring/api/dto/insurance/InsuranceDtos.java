package io.ltj.restructuring.api.dto.insurance;

public class InsuranceDtos {
}
