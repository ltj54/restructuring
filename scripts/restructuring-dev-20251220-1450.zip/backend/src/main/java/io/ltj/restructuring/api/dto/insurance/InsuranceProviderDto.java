package io.ltj.restructuring.api.dto.insurance;

public record InsuranceProviderDto(
        String name
) {
}
