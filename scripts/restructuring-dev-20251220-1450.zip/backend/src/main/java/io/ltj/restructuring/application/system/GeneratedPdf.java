package io.ltj.restructuring.application.system;

public record GeneratedPdf(
        String fileName,
        byte[] content
) { }
