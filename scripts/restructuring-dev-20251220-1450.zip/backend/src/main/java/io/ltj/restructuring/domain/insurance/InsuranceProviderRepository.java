package io.ltj.restructuring.domain.insurance;

public class InsuranceProviderRepository {
}
