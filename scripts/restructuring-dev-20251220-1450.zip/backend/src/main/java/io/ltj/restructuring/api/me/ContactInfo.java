package io.ltj.restructuring.api.me;

public class ContactInfo {
    public String firstName;
    public String lastName;
    public String ssn;
    public String phone;
}
