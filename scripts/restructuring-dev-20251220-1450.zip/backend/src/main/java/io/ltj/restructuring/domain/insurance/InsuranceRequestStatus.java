package io.ltj.restructuring.domain.insurance;

public enum InsuranceRequestStatus {
    SENT,
    RECEIVED,
    PROCESSED
}
