package io.ltj.restructuring.logging;

public enum FrontendLogLevel {
    INFO,
    WARN,
    ERROR
}
