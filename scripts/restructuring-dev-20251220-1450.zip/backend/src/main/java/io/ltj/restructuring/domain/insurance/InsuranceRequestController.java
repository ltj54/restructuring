package io.ltj.restructuring.api.insurance;

import io.ltj.restructuring.domain.insurance.InsuranceRequest;
import io.ltj.restructuring.domain.insurance.InsuranceRequestRepository;
import io.ltj.restructuring.security.JwtUserDetails;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/insurance")
public class InsuranceRequestController {

    private final InsuranceRequestRepository repository;

    public InsuranceRequestController(InsuranceRequestRepository repository) {
        this.repository = repository;
    }

    @PostMapping("/request")
    public InsuranceRequest submit(
            @RequestBody InsuranceRequest request,
            Authentication authentication
    ) {
        if (authentication == null || !(authentication.getPrincipal() instanceof JwtUserDetails)) {
            throw new IllegalStateException("No authenticated user");
        }

        JwtUserDetails user = (JwtUserDetails) authentication.getPrincipal();

        // 🔒 Viktig: sett userId server-side
        request.setUserId(user.getId());

        return repository.save(request);
    }
}
