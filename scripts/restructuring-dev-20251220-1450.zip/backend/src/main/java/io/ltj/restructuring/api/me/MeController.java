package io.ltj.restructuring.api.me;

import io.ltj.restructuring.security.JwtUserDetails;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@RestController
@RequestMapping("/api/me")
public class MeController {

    private final Map<Long, ContactInfo> contactStore = new ConcurrentHashMap<>();

    @GetMapping
    public Map<String, Object> me(Authentication authentication) {
        JwtUserDetails user = requireUser(authentication);

        return Map.of(
                "userId", user.getId(),
                "email", user.getUsername(),
                "authorities", user.getAuthorities()
                        .stream()
                        .map(a -> a.getAuthority())
                        .toList()
        );
    }

    @GetMapping("/contact")
    public ContactInfo getContact(Authentication authentication) {
        JwtUserDetails user = requireUser(authentication);
        return contactStore.getOrDefault(user.getId(), new ContactInfo());
    }

    @PostMapping("/contact")
    public ContactInfo saveContact(
            @RequestBody ContactInfo contact,
            Authentication authentication
    ) {
        JwtUserDetails user = requireUser(authentication);

        // 👇 logg for å se at den faktisk blir kalt
        System.out.println("LAGRER CONTACT FOR USER " + user.getId());

        contactStore.put(user.getId(), contact);
        return contact;
    }

    private JwtUserDetails requireUser(Authentication authentication) {
        if (authentication == null || !(authentication.getPrincipal() instanceof JwtUserDetails)) {
            throw new IllegalStateException("No authenticated user");
        }
        return (JwtUserDetails) authentication.getPrincipal();
    }
}
