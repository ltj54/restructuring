package io.ltj.restructuring.api.dto.user;

public record UserResponseDto(
        Long id,
        String email,
        String firstName,
        String lastName,
        String ssn,
        String phone
) {
}
