import React from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

/**
 * ProtectedLayout
 *
 * - Viser innhold hvis bruker er innlogget
 * - Sender til /login hvis ikke innlogget
 * - Laster først til vi vet auth-status
 * - Hindrer redirect-bugs og open-redirect
 */
export default function ProtectedLayout() {
  const { isAuthenticated, isLoadingUser } = useAuth();
  const location = useLocation();

  // 1) Ikke ferdig lastet → vis ingenting for å unngå redirect-flimmer
  if (isLoadingUser) {
    return null;
  }

  // 2) Ikke logget inn → send til login med trygg redirect tilbake
  if (!isAuthenticated) {
    const raw = location.pathname + location.search + location.hash;

    // 🚨 Sikkerhet: hindre redirect til eksterne adresser
    const safe = raw.startsWith('/') ? raw : '/';

    const redirectTo = encodeURIComponent(safe);

    return <Navigate to={`/login?redirect=${redirectTo}`} replace />;
  }

  // 3) Logget inn → vis siden
  return <Outlet />;
}
