import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import Card from '@/components/Card';
import Button from '@/components/Button';
import PageLayout from '@/components/PageLayout';
import { API_BASE_URL } from '@/utils/config';
import { useAuth } from '@/hooks/useAuth';

type Health = 'ok' | 'feil' | 'ukjent';

type HealthResponse = {
  status: string;
  timestamp?: string;
  details?: Record<string, unknown>;
};

type DbInfo = {
  database?: string;
  version?: string;
  driver?: string;
  driverVersion?: string;
  schema?: string;
  error?: string;
};

type HistoryEntry = {
  time: Date;
  status: Health;
  httpCode: number | null;
  durationMs: number;
};

function isAdminFromToken(token: string | null): boolean {
  if (!token) return false;
  try {
    const [, payload] = token.split('.');
    const json = JSON.parse(atob(payload));
    const authorities = (json?.authorities ?? []) as string[];
    return authorities.includes('ROLE_ADMIN');
  } catch {
    return false;
  }
}

export default function SystemInfoPage() {
  const { token } = useAuth();

  const isAdmin = useMemo(() => isAdminFromToken(token), [token]);

  const [status, setStatus] = useState<Health>('ukjent');
  const [forbidden, setForbidden] = useState(false);
  const [httpCode, setHttpCode] = useState<number | null>(null);
  const [lastChecked, setLastChecked] = useState<Date | null>(null);
  const [message, setMessage] = useState('');
  const [checking, setChecking] = useState(false);

  const [healthDetails, setHealthDetails] = useState<HealthResponse | null>(null);

  const [dbStatus, setDbStatus] = useState<Health>('ukjent');
  const [dbMessage, setDbMessage] = useState('');
  const [dbInfo, setDbInfo] = useState<DbInfo | null>(null);

  const [history, setHistory] = useState<HistoryEntry[]>([]);

  const [users, setUsers] = useState<Array<Record<string, unknown>>>([]);
  const [usersLoading, setUsersLoading] = useState(false);
  const [usersError, setUsersError] = useState('');

  const [userIdInput, setUserIdInput] = useState('');
  const [userProfileLoading, setUserProfileLoading] = useState(false);
  const [userProfileError, setUserProfileError] = useState('');
  const [userProfileRaw, setUserProfileRaw] = useState('');

  const healthUrl = useMemo(() => `${API_BASE_URL}/system/health`, []);
  const dbInfoUrl = useMemo(() => `${API_BASE_URL}/system/dbinfo`, []);
  const userProfileBaseUrl = useMemo(() => `${API_BASE_URL}/system/user-profile`, []);
  const usersUrl = useMemo(() => `${API_BASE_URL}/system/users`, []);

  // ---------------------------------------
  // Backend check
  // ---------------------------------------
  const checkBackend = useCallback(async () => {
    setChecking(true);
    setMessage('');

    const start = performance.now();
    let newStatus: Health = 'ukjent';
    let code: number | null = null;

    try {
      const res = await fetch(healthUrl);
      code = res.status;
      setHttpCode(code);

      if (res.ok) {
        const data = (await res.json()) as HealthResponse;
        const timeText = data?.timestamp
          ? ` (oppdatert ${new Date(data.timestamp).toLocaleTimeString()})`
          : '';
        newStatus = 'ok';
        setStatus('ok');
        setForbidden(false);
        setHealthDetails(data);
        setMessage(`Backend svarer som forventet.${timeText}`);
      } else if (res.status === 403) {
        newStatus = 'feil';
        setStatus('feil');
        setForbidden(true);
        setHealthDetails(null);
        setMessage('403: Du har ikke tilgang til Systeminfo. Logg inn som ADMIN.');
      } else {
        newStatus = 'feil';
        setStatus('feil');
        setForbidden(false);
        setHealthDetails(null);
        setMessage('Backend svarte, men med feil.');
      }
    } catch {
      newStatus = 'feil';
      setStatus('feil');
      setForbidden(false);
      setHttpCode(null);
      setHealthDetails(null);
      setMessage('Klarte ikke å kontakte backend.');
    } finally {
      const end = performance.now();
      const durationMs = Math.round(end - start);
      setChecking(false);
      setLastChecked(new Date());

      setHistory((prev) => {
        const entry: HistoryEntry = {
          time: new Date(),
          status: newStatus,
          httpCode: code,
          durationMs,
        };
        return [entry, ...prev].slice(0, 10);
      });
    }
  }, [healthUrl]);

  // ---------------------------------------
  // DB check
  // ---------------------------------------
  const checkDb = useCallback(async () => {
    setDbMessage('');

    try {
      const res = await fetch(dbInfoUrl);
      if (!res.ok) {
        setDbStatus('feil');
        setDbInfo(null);
        setDbMessage('Klarte ikke å hente DB-info.');
        return;
      }
      const data = (await res.json()) as DbInfo;
      if ((data as DbInfo).error) {
        setDbStatus('feil');
        setDbInfo(data);
        setDbMessage(String((data as DbInfo).error));
        return;
      }
      setDbStatus('ok');
      setDbInfo(data);
      setDbMessage('Database ser OK ut.');
    } catch {
      setDbStatus('feil');
      setDbInfo(null);
      setDbMessage('Kunne ikke kontakte DB-endepunktet.');
    }
  }, [dbInfoUrl]);

  // ---------------------------------------
  // Users (admin)
  // ---------------------------------------
  const fetchUsers = useCallback(async () => {
    setUsersLoading(true);
    setUsersError('');
    try {
      const res = await fetch(usersUrl);
      if (!res.ok) {
        setUsersError('Kunne ikke hente brukere.');
        setUsers([]);
        return;
      }
      const data = (await res.json()) as { users?: Array<Record<string, unknown>> };
      setUsers(Array.isArray(data?.users) ? data.users : []);
    } catch {
      setUsersError('Kunne ikke hente brukere.');
      setUsers([]);
    } finally {
      setUsersLoading(false);
    }
  }, [usersUrl]);

  // ---------------------------------------
  // User profile (admin)
  // ---------------------------------------
  const fetchUserProfile = useCallback(async () => {
    setUserProfileLoading(true);
    setUserProfileError('');
    setUserProfileRaw('');

    const id = userIdInput.trim();
    if (!id) {
      setUserProfileError('Skriv inn en bruker-id.');
      setUserProfileLoading(false);
      return;
    }

    try {
      const res = await fetch(`${userProfileBaseUrl}/${encodeURIComponent(id)}`);
      if (!res.ok) {
        setUserProfileError('Kunne ikke hente brukerprofil.');
        setUserProfileLoading(false);
        return;
      }
      const text = await res.text();
      setUserProfileRaw(text);
    } catch {
      setUserProfileError('Kunne ikke hente brukerprofil.');
      setUserProfileRaw('');
    } finally {
      setUserProfileLoading(false);
    }
  }, [userIdInput, userProfileBaseUrl]);

  // ---------------------------------------
  // Auto loop
  // ---------------------------------------
  useEffect(() => {
    let id: number | null = null;

    async function loop() {
      if (forbidden) {
        if (id) clearInterval(id);
        return;
      }

      await checkBackend();

      if (status === 'ok') {
        await checkDb();
      }

      if (status === 'ok' && dbStatus === 'ok') {
        if (id) clearInterval(id);
      }
    }

    loop();
    id = window.setInterval(loop, 3000);

    return () => id && clearInterval(id);
  }, [status, dbStatus, forbidden, checkBackend, checkDb]);

  // Hent brukere én gang når backend er ok
  useEffect(() => {
    if (status === 'ok' && isAdmin) {
      fetchUsers();
    }
  }, [status, fetchUsers, isAdmin]);

  const loading = status !== 'ok';

  return (
    <PageLayout
      title="Systemstatus"
      subtitle="Enkel og ryddig oversikt over backend, database og nylige målinger."
      maxWidthClassName="max-w-5xl"
    >
      {/* BOOT BANNER */}
      {loading && (
        <motion.div
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700"
        >
          {forbidden ? (
            <div>
              <div className="font-semibold">Ingen tilgang</div>
              <div className="mt-1">
                Systeminfo er kun for ADMIN. Logg inn med en ADMIN-bruker for å se denne siden.
              </div>
            </div>
          ) : (
            <div>
              <div className="font-semibold">Starter…</div>
              <div className="mt-1">Venter på at backend skal svare.</div>
            </div>
          )}
        </motion.div>
      )}

      <div className="grid grid-cols-1 gap-6">
        <Card>
          <div className="flex items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-semibold text-slate-900">Backend</h2>
              <p className="text-sm text-slate-600">Sjekker /system/health</p>
            </div>

            <Button onClick={checkBackend} disabled={checking}>
              {checking ? 'Sjekker…' : 'Sjekk nå'}
            </Button>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="rounded-lg border border-slate-200 bg-white p-3 text-sm">
              <p className="font-semibold text-slate-700">Status</p>
              <p className="text-slate-600 mt-1">{status}</p>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-3 text-sm">
              <p className="font-semibold text-slate-700">HTTP</p>
              <p className="text-slate-600 mt-1">{httpCode ?? '—'}</p>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-3 text-sm">
              <p className="font-semibold text-slate-700">Sist sjekket</p>
              <p className="text-slate-600 mt-1">
                {lastChecked ? lastChecked.toLocaleTimeString() : '—'}
              </p>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-3 text-sm">
              <p className="font-semibold text-slate-700">Melding</p>
              <p className="text-slate-600 mt-1">{message}</p>
            </div>
          </div>

          <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs">
            <p className="font-semibold text-slate-700 mb-1">Health URL</p>
            <p className="break-all text-slate-600">{healthUrl}</p>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-semibold text-slate-900">Database</h2>
              <p className="text-sm text-slate-600">Sjekker /system/dbinfo</p>
            </div>

            <Button onClick={checkDb}>Sjekk DB</Button>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="rounded-lg border border-slate-200 bg-white p-3 text-sm">
              <p className="font-semibold text-slate-700">Status</p>
              <p className="text-slate-600 mt-1">{dbStatus}</p>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-3 text-sm">
              <p className="font-semibold text-slate-700">Melding</p>
              <p className="text-slate-600 mt-1">{dbMessage}</p>
            </div>
          </div>

          {dbInfo && (
            <pre className="mt-4 rounded-xl bg-slate-900 text-slate-50 p-4 text-xs overflow-auto">
              {JSON.stringify(dbInfo, null, 2)}
            </pre>
          )}
        </Card>

        <Card>
          <h2 className="text-lg font-semibold text-slate-900">Historikk</h2>
          <div className="mt-3 space-y-2 text-sm">
            {history.map((h, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between rounded-lg border border-slate-200 bg-white px-3 py-2"
              >
                <div className="text-slate-700">{h.time.toLocaleTimeString()}</div>
                <div className="text-slate-600">
                  {h.status} / {h.httpCode ?? '—'} / {h.durationMs}ms
                </div>
              </div>
            ))}
          </div>
        </Card>

        {isAdmin && (
          <Card>
            <div className="flex items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-semibold text-slate-900">Brukere</h2>
                <p className="text-sm text-slate-600">Admin-oversikt</p>
              </div>

              <Button onClick={fetchUsers} disabled={usersLoading}>
                {usersLoading ? 'Laster…' : 'Oppdater'}
              </Button>
            </div>

            {usersError && <p className="mt-3 text-sm text-red-600">{usersError}</p>}

            <pre className="mt-4 rounded-xl bg-slate-900 text-slate-50 p-4 text-xs overflow-auto">
              {JSON.stringify(users, null, 2)}
            </pre>

            <div className="mt-6 border-t border-slate-200 pt-4">
              <h3 className="font-semibold text-slate-900">Brukerprofil</h3>

              <div className="mt-3 flex gap-3">
                <input
                  className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
                  placeholder="User ID"
                  value={userIdInput}
                  onChange={(e) => setUserIdInput(e.target.value)}
                />
                <Button onClick={fetchUserProfile} disabled={userProfileLoading}>
                  {userProfileLoading ? 'Henter…' : 'Hent'}
                </Button>
              </div>

              {userProfileError && <p className="mt-2 text-sm text-red-600">{userProfileError}</p>}

              {userProfileRaw && (
                <pre className="mt-4 rounded-xl bg-slate-900 text-slate-50 p-4 text-xs overflow-auto">
                  {userProfileRaw}
                </pre>
              )}
            </div>
          </Card>
        )}
      </div>
    </PageLayout>
  );
}
