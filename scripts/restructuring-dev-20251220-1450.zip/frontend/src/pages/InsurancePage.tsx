import React, { useEffect, useMemo, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { fetchJson } from '@/utils/api';

type ContactInfo = {
  firstName: string;
  lastName: string;
  ssn: string;
  phone: string;
};

const EMPTY_CONTACT: ContactInfo = {
  firstName: '',
  lastName: '',
  ssn: '',
  phone: '',
};

export default function InsurancePage() {
  const { isAuthenticated } = useAuth();
  const [contact, setContact] = useState<ContactInfo>(EMPTY_CONTACT);
  const [status, setStatus] = useState<string | null>(null);

  /* =========================
     LOAD CONTACT
  ========================= */

  useEffect(() => {
    if (!isAuthenticated) {
      setContact(EMPTY_CONTACT);
      return;
    }

    fetchJson<ContactInfo>('/api/me/contact')
      .then(setContact)
      .catch(() => {
        setStatus('Kunne ikke hente kontaktinfo');
      });
  }, [isAuthenticated]);

  /* =========================
     SAVE CONTACT
  ========================= */

  const saveContact = async () => {
    setStatus(null);
    try {
      const saved = await fetchJson<ContactInfo>('/api/me/contact', {
        method: 'POST',
        body: JSON.stringify(contact),
      });
      setContact(saved);
      setStatus('Kontaktinfo lagret ✔');
    } catch (e) {
      setStatus('Lagring feilet (sjekk innlogging)');
    }
  };

  /* =========================
     GENERATED TEXT
  ========================= */

  const generatedText = useMemo(() => {
    return `Hei Gjensidige,
Kan dere kontakte meg for et tilbud?`;
  }, []);

  /* =========================
     RENDER
  ========================= */

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="space-y-3">
        {!isAuthenticated && (
          <div className="rounded border bg-amber-50 p-3 text-sm">
            Logg inn for å lagre kontaktinfo.
          </div>
        )}

        <input
          placeholder="Fornavn"
          value={contact.firstName}
          onChange={(e) =>
            setContact({ ...contact, firstName: e.target.value })
          }
        />

        <input
          placeholder="Etternavn"
          value={contact.lastName}
          onChange={(e) =>
            setContact({ ...contact, lastName: e.target.value })
          }
        />

        <input
          placeholder="Fødselsnummer"
          value={contact.ssn}
          onChange={(e) =>
            setContact({ ...contact, ssn: e.target.value })
          }
        />

        <input
          placeholder="Telefon"
          value={contact.phone}
          onChange={(e) =>
            setContact({ ...contact, phone: e.target.value })
          }
        />

        {isAuthenticated && (
          <button onClick={saveContact}>
            Lagre kontaktinfo
          </button>
        )}

        {status && <div className="text-sm">{status}</div>}
      </div>

      <div>
        <textarea
          readOnly
          value={generatedText}
          className="w-full h-48"
        />
      </div>
    </div>
  );
}
