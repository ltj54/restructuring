This directory is a fallback for `exports["./client"]` in the root `framer-motion` `package.json`.
