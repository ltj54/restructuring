# @vitest/spy

Lightweight Jest compatible spy implementation.
